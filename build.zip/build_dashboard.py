#!/usr/bin/env python3
# Self-contained Wind Analytics dashboard builder.
# Inputs in cwd: workstudy.xlsx, leave.xlsx (Google Sheets exported as xlsx),
#                asana.json (list of {name,total,done,open,gid}), and today (YYYY-MM-DD) via TODAY env or arg.
# Output: wind_ops_dashboard.html
import pandas as pd, warnings, json, sys, os, re, datetime
warnings.filterwarnings('ignore')
TODAY_STR=(sys.argv[1] if len(sys.argv)>1 else os.environ.get('TODAY','2026-07-24'))
TODAY=pd.Timestamp(TODAY_STR)
# Build timestamp in IST (Asia/Kolkata = UTC+5:30). Override with GEN_TS env ("YYYY-MM-DD HH:MM") for manual rebuilds.
GEN_TS=os.environ.get('GEN_TS') or (datetime.datetime.utcnow()+datetime.timedelta(hours=5,minutes=30)).strftime('%Y-%m-%d %H:%M')

def build_data():
    # roster sections
    el=pd.read_excel('workstudy.xlsx','Employee List',header=None)
    group={};role={};name={};cur='Analysts'
    for i,row in el.iterrows():
        a=str(row[0]).strip() if pd.notna(row[0]) else ''
        b=str(row[1]).strip() if pd.notna(row[1]) else ''
        c=str(row[2]).strip() if pd.notna(row[2]) else ''
        if a=='Name' and b=='Employee Email': continue
        if a and b=='' and c=='':
            cur='Analysts' if a=='(top)' else a; continue
        if '@zeitview' in b:
            e=b.lower();name[e]=a;role[e]=c;group[e]=cur
    tm=pd.read_excel('leave.xlsx','Team',header=3);tm.columns=[str(x).strip() for x in tm.columns]
    proc={}
    for _,r in tm.iterrows():
        e=str(r.get('Employee Email','')).strip().lower()
        if '@zeitview' in e:
            proc[e]=str(r.get('Expertise Process','')).strip()
            name.setdefault(e,str(r.get('Name','')).strip());role.setdefault(e,str(r.get('Role','')).strip())
    nm=lambda e:name.get(str(e).lower().strip()) or str(e).split('@')[0].replace('.',' ').title()
    # productivity
    df=pd.read_excel('workstudy.xlsx','User Input',header=0);df.columns=[str(c).strip() for c in df.columns]
    meta=['Emplyoee Name','Output_Date','Data Added By','Timestamp','Which Backend Sheets Updated ?','Output Entry Status',"Team Lead's Notes"]
    wc=[c for c in df.columns if c not in meta and not c.startswith('Unnamed')]
    df=df[df['Emplyoee Name'].astype(str).str.contains('@zeitview',na=False)].copy()
    df['date']=pd.to_datetime(df['Output_Date'],errors='coerce');df=df.dropna(subset=['date'])
    df['_ow']=df['Other_Work'].astype(str) if 'Other_Work' in df.columns else ''
    for c in wc: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0)
    df['email']=df['Emplyoee Name'].str.strip().str.lower();df['tot']=df[wc].sum(axis=1)
    ci={c:i for i,c in enumerate(wc)}
    cat=df[wc].sum();cat=cat[cat>0].sort_values(ascending=False)
    bym=df.groupby(df['date'].dt.strftime('%Y-%m'))['tot'].sum().round(0)
    byd=df.groupby(df['date'].dt.date)['tot'].sum().round(0)
    byp=df.groupby('email')['tot'].sum().sort_values(ascending=False)
    bcm={}
    for m,g in df.groupby(df['date'].dt.strftime('%Y-%m')):
        s=g[wc].sum();s=s[s>0].sort_values(ascending=False);bcm[m]={c:round(float(s[c])) for c in s.index[:11]}
    def grp(c):
        if c.startswith('Ext_') or c=='Critical Review':return 'External Blade'
        if c.startswith('Int_'):return 'Internal Blade'
        if c.startswith('ZDT'):return 'ZDT (Zero Down Time)'
        if c in('Nacelle','Tower','HUB Inspection','Cooler Top'):return 'Turbine Inspection'
        if 'Data Process' in c:return 'Data Process'
        if c in('Pilot-Uploaders','Skyspecs Data upload'):return 'Uploads'
        return 'Other'
    pg={}
    for c in cat.index:pg[grp(c)]=pg.get(grp(c),0)+float(cat[c])
    per={}
    for e,g in df.groupby('email'):
        cs=g[wc].sum();cs=cs[cs>0].sort_values(ascending=False)
        bm=g.groupby(g['date'].dt.strftime('%Y-%m'))['tot'].sum()
        daily={};notes={}
        for dt,gg in g.groupby(g['date'].dt.strftime('%Y-%m-%d')):
            sm=gg[wc].sum();rec=[[ci[c],round(float(sm[c]),2)] for c in wc if sm[c]>0]
            if rec:daily[dt]=rec
            ow=[str(x).strip() for x in gg['_ow'].tolist() if str(x).strip() and str(x).strip().lower() not in ('0','0.0','nan')]
            ow=[t for t in ow if not re.fullmatch(r'-?\d+(\.\d+)?',t)]
            if ow:notes[dt]='; '.join(dict.fromkeys(ow))
        per[e]=dict(email=e,name=nm(e),role=role.get(e,''),group=group.get(e,''),proc=proc.get(e,''),
            units=round(float(g['tot'].sum())),days=int(g['date'].dt.date.nunique()),last=str(g['date'].max().date()),
            top_cats=[[c.replace('_',' '),round(float(cs[c]))] for c in cs.index[:4]],
            by_month={m:round(float(v)) for m,v in bm.items()},d=daily,nt=notes)
    for rk,e in enumerate(sorted(per,key=lambda x:-per[x]['units']),1):per[e]['rank']=rk
    # leave
    lv=pd.read_excel('leave.xlsx','Tracker',header=0);lv.columns=[str(c).strip() for c in lv.columns]
    lv=lv[lv['Workflow ID'].notna() & lv['Request from'].astype(str).str.contains('@zeitview',na=False)].copy()
    lv['start']=pd.to_datetime(lv['Start Date'],errors='coerce');lv['end']=pd.to_datetime(lv['End Date'],errors='coerce')
    lv['email']=lv['Request from'].str.strip().str.lower();lv['status']=lv['Approval Status'].astype(str).str.strip()
    lv['code']=lv['Request Type'].astype(str).str.strip();lv['ltype']=lv['Request'].astype(str).str.replace('Time Off - ','',regex=False).str.strip()
    # "Comp Working" (Compensatory Working / CW+) and "WFH" (Work From Home) = the person IS working that day, not off. Drop from all leave / out-today stats. (Comp Off / CW- stays counted as off.)
    _code=lv['code'].astype(str).str.strip().str.lower()
    _cw=lv['Request'].astype(str).str.contains('Compensatory Working',case=False,na=False)|(_code=='working')|(_code=='wfh')
    lv=lv[~_cw].copy()
    lv=lv.dropna(subset=['start'])
    lv26=lv[(lv['start']>=pd.Timestamp('2026-01-01'))&(lv['start']<pd.Timestamp('2027-01-01'))]
    onl=lv[(lv['start']<=TODAY)&(lv['end'].fillna(lv['start'])>=TODAY)]
    up=lv[(lv['start']>TODAY)&(lv['start']<=TODAY+pd.Timedelta(days=14))].sort_values('start')
    for e in per:per[e].update(leave=0,planned=0,unplanned=0,on_leave=False,leave_code='',upcoming=[],lv=[])
    def ens(e):
        if e not in per:per[e]=dict(email=e,name=nm(e),role=role.get(e,''),group=group.get(e,''),proc=proc.get(e,''),units=0,days=0,last='',top_cats=[],by_month={},d={},nt={},rank=None,leave=0,planned=0,unplanned=0,on_leave=False,leave_code='',upcoming=[],lv=[])
    for e,g in lv26.groupby('email'):
        ens(e);per[e]['leave']=int(len(g));per[e]['planned']=int((g['ltype']=='Planned').sum());per[e]['unplanned']=int((g['ltype']=='Unplanned').sum())
    for _,r in onl.iterrows():ens(r['email']);per[r['email']]['on_leave']=True;per[r['email']]['leave_code']=r['code']
    for _,r in up.iterrows():ens(r['email']);per[r['email']]['upcoming'].append({'code':r['code'],'start':str(r['start'].date()),'end':str((r['end'] if pd.notna(r['end']) else r['start']).date())})
    lvall=lv[(lv['start']>=pd.Timestamp('2025-12-01'))&(lv['start']<pd.Timestamp('2027-01-01'))]
    for e,g in lvall.groupby('email'):
        ens(e)
        per[e]['lv']=[[str(r['start'].date()),str((r['end'] if pd.notna(r['end']) else r['start']).date()),r['code'],r['ltype'],r['status']] for _,r in g.iterrows()]
    codes=lv26['code'].value_counts()
    def nmn(e):return per[e]['name'] if e in per else nm(e)
    onl_list=[{'name':nmn(r['email']),'code':r['code'],'start':str(r['start'].date()),'end':str((r['end'] if pd.notna(r['end']) else r['start']).date())} for _,r in onl.iterrows()]
    up_list=[{'name':nmn(r['email']),'code':r['code'],'start':str(r['start'].date()),'end':str((r['end'] if pd.notna(r['end']) else r['start']).date()),'type':r['ltype']} for _,r in up.iterrows()]
    # asana
    aj=json.load(open('asana.json'))
    projects=[dict(name=p['name'],total=p['total'],done=p['done'],open=p['open'],pct=round(p['done']/p['total']*100) if p['total'] else 0,url=f"https://app.asana.com/0/{p['gid']}/list") for p in aj]
    def stage(nm_,fallback):
        for p in projects:
            if nm_.lower() in p['name'].lower():return {'stage':fallback,'done':p['done'],'open':p['open']}
        return {'stage':fallback,'done':0,'open':0}
    pipeline=[stage('Prescreen','Prescreen'),stage('Analysis - Wind','Analysis'),stage('FQC','FQC'),stage('Critical Damages','Critical Damages')]
    asana=dict(total=sum(p['total'] for p in projects),done=sum(p['done'] for p in projects),open=sum(p['open'] for p in projects),projects=projects,pipeline=pipeline)
    tg={'Analysts':56,'GWO':15,'WFH':9,'Data Process':6,'LM Blade Pilot':2}
    prod=dict(total=round(float(df['tot'].sum())),entries=int(len(df)),contributors=int((byp>0).sum()),
        date_min=str(df['date'].min().date()),date_max=str(df['date'].max().date()),active_days=int(df['date'].dt.date.nunique()),
        by_category={c:round(float(v)) for c,v in cat.items()},by_group={k:round(v) for k,v in sorted(pg.items(),key=lambda x:-x[1])},
        by_month={m:round(float(v)) for m,v in bym.items()},by_day={str(k):round(float(v)) for k,v in byd.items()},
        by_category_month=bcm,top_people=[{'name':per[e]['name'],'role':per[e]['role'],'total':round(float(v))} for e,v in byp.head(15).items()])
    prod['avg_per_day']=round(prod['total']/prod['active_days'],1)
    leave=dict(total=int(len(lv26)),approved=int((lv26['status'].str.lower()=='approved').sum()),declined=int((lv26['status'].str.lower()=='declined').sum()),
        planned=int((lv26['ltype']=='Planned').sum()),unplanned=int((lv26['ltype']=='Unplanned').sum()),
        by_code={k:int(v) for k,v in codes.head(10).items()},by_month={m:int(v) for m,v in lv26.groupby(lv26['start'].dt.strftime('%Y-%m')).size().items()},
        by_type={k:int(v) for k,v in lv26['ltype'].value_counts().items()},on_leave_today=onl_list,upcoming=up_list,
        top_takers=[{'name':nmn(e),'count':int(v)} for e,v in lv26['email'].value_counts().head(10).items()],
        team_size=sum(tg.values()),team_groups=tg)
    people=sorted(per.values(),key=lambda x:-(x['units'] or 0))
    return dict(generated=TODAY_STR,gen_ts=GEN_TS,productivity=prod,leave=leave,asana=asana,people=people,catList=wc)

if __name__=='__main__':
    data=build_data()
    DATA=json.dumps(data,separators=(',',':'))
    try:
        INV=open('inventory.json').read().strip() or 'null'
    except Exception:
        INV='null'
    tpl=open('dashboard_template.html').read()
    tpl=tpl.replace('__DATA__',DATA).replace('__INV__',INV)
    open('wind_ops_dashboard.html','w').write(tpl)
    print('built wind_ops_dashboard.html', round(len(DATA)/1024),'KB data +',round(len(INV)/1024),'KB inventory')
